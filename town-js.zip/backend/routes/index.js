const adminRouter = require('./admin');
// يمكن إضافة راوترات أخرى هنا لاحقًا

module.exports = {
  adminRouter,
};
