import React from 'react';

export default function StatsSection() {
  return null;
}