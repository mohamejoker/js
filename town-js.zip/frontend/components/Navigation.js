import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'next-i18next';
import { useRouter } from 'next/router';
import { Sparkles, Menu, X, Globe } from 'lucide-react';

export default function Navigation() {
  return null;
}