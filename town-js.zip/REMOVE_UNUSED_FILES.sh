# حذف الملفات غير المستخدمة

rm backend/models/User.js
